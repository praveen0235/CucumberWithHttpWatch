package stepDefinitions;


import org.junit.Assert;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.assertj.core.api.SoftAssertions;

import baseinit.Base;
import config.PropertyFileReader;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import framework.Elements;
import framework.Waits;
import pageObjects.pageObjects;
import reporter.ExtentCucumberAdapter;

public class Steps {
	
	SoftAssertions sft = new SoftAssertions();
	
	@Given("navigate to given URL")
	public void navigate_to_given_URL() {
	    
		Base.driver.navigate().to(PropertyFileReader.properties.getProperty("url"));
	}
	
	@Then("click on toggle menu")
	public void click_on_toggle_menu() throws InterruptedException {
		Thread.sleep(1000);
		Waits.waitUntilElementToClick(30,pageObjects.Menu);
		Elements.click(pageObjects.Menu);
	    
	}
	
	@Then("click on login button and dashborad should display")
	public void click_on_login_button_and_dashborad_should_display() throws InterruptedException {
		Waits.waitUntilElementToClick(30,pageObjects.SignInButton);
		Elements.click(pageObjects.SignInButton);
	}
	
	@Then("dashborad should display")
	public void dashborad_should_display() {
		
		try
		{
			Waits.waitUntilElementLocated(30, pageObjects.AlertMsg);
			ExtentCucumberAdapter.errorMessage=	pageObjects.AlertMsg.getText();
			ExtentCucumberAdapter.typeofError="Login";
		}catch(Exception e)
		{
			
		}

		Waits.waitUntilElementLocated(30, pageObjects.Dashboard);
		Elements.VerifyTextEquals(pageObjects.Dashboard, "UD's Corporation. LLC");
	}
	
	@Then("Switch to {string}")
	public void switch_to(String string) {
		Waits.waitUntilElementToClick(100,pageObjects.SwitchToRole_Radiobtn(string));
		Elements.click(pageObjects.SwitchToRole_Radiobtn(string));
	    
	}
	@Then("Click on SwitchTo option")
	public void click_on_SwitchTo_option() {
	    
		Waits.waitUntilElementToClick(100,pageObjects.SwitchToRole);
		Elements.click(pageObjects.SwitchToRole);
	}

	@Then("click OK button")
	public void click_OK_button() {
	    
		Waits.waitUntilElementToClick(100,pageObjects.OK_btn);
		Elements.click(pageObjects.OK_btn);
	    
	}
	
	@Then("enter admin username and click next button")
	public void enter_admin_username_as_and_click_next_button() throws InterruptedException {
		pageObjects obj = new pageObjects(Base.driver);
		Elements.TypeText(pageObjects.username, PropertyFileReader.properties.getProperty("Admin_username"));
		Thread.sleep(1500);
		Elements.click(pageObjects.Next_btn);
	}

	@Then("enter admin password")
	public void enter_admin_password_as() throws InterruptedException {
		Thread.sleep(5000);
		Elements.TypeText(pageObjects.password, PropertyFileReader.properties.getProperty("Admin_Password"));
	}
	
	@Then("select Inventory Reort from dropdown")
	public void select_Inventory_Reort_from_dropdown() throws InterruptedException {
		Thread.sleep(5000);
		Elements.click(pageObjects.Reports_drpdwn);
		Thread.sleep(2000);
		Elements.click(pageObjects.InventoryReport);
	}
	
	@Then("Click on DCN number")
	public void Click_on_DCN_number() throws InterruptedException {
		Elements.jclick(pageObjects.DCNNumber);
		
	}
	
	@Then("Verify PDF has loaded")
	public void Verify_PDF_has_loaded() throws InterruptedException, MalformedURLException, IOException {
		Elements.switchToChild();
		
		HttpsURLConnection.setFollowRedirects(false);
		HttpsURLConnection con = (HttpsURLConnection) new URL(Base.driver.getCurrentUrl()).openConnection();
        con.setRequestMethod("HEAD");
        int a =con.getResponseCode();
        int b=HttpURLConnection.HTTP_OK;
       Assert.assertTrue(a == b);
       
       Elements.switchToParentWindow();
	}
	
	@Then("enter mail username and click next button")
	public void enter_mail_username_as_and_click_next_button() throws InterruptedException {
		pageObjects obj = new pageObjects(Base.driver);
		Elements.TypeText(pageObjects.username, PropertyFileReader.properties.getProperty("Mail_username"));
		Thread.sleep(1500);
		Elements.click(pageObjects.Next_btn);
	}

	@Then("enter mail user password")
	public void enter_mail_password_as() throws InterruptedException {
		Thread.sleep(5000);
		Elements.TypeText(pageObjects.password, PropertyFileReader.properties.getProperty("Mail_Password"));
	}

	@Then("click on login button")
	public void click_on_login_button() {
		Elements.click(pageObjects.SignInButton);
	}

	@Then("redirect the page to {string}")
	public void redirect_the_page_to(String URL) throws InterruptedException {
		Thread.sleep(5000);
		Base.driver.navigate().to(URL);
	
	}

	@Then("DMR core & DB, Ingester ,Exela auth & DB and eFirst-Archive status should be in {string} status")
	public void dmr_core_status_should_be_and_DMR_db_status_should_be(String status) throws InterruptedException {
		Thread.sleep(5000);
		String test = Elements.getText(pageObjects.DMR_CORE_Status);
		sft.assertThat(test).isEqualTo(status);
		sft.assertThat(Elements.getText(pageObjects.DMR_CORE_DBStatus)).isEqualTo(status);
		sft.assertThat(Elements.getText(pageObjects.Ingester_Status)).isEqualTo(status);
		sft.assertThat(Elements.getText(pageObjects.eFirst_Archive_DEMO_Status)).isEqualTo(status);
		sft.assertThat(Elements.getText(pageObjects.Exela_Auth_Status)).isEqualTo(status);
		sft.assertThat(Elements.getText(pageObjects.Exela_Auth_DBStatus)).isEqualTo(status);
		sft.assertAll();	
	}

	@Then("click on profile pic")
	public void click_on_profile_pic() throws InterruptedException {
		Thread.sleep(5000);
		Elements.click(pageObjects.Profile_Pic);
	}

	@Then("logOut")
	public void logout() throws InterruptedException {
		Thread.sleep(1500);
		Elements.click(pageObjects.Logout);
	}

	@Then("select and open an email")
	public void select_and_open_an_email() throws InterruptedException {
		
		Elements.click(pageObjects.Mail_Selection);
		Thread.sleep(2000);
		Elements.mouseDoubleclick(pageObjects.DoubleClick_OpenMail);
	}

	@Then("check if PDF is displayed")
	public void check_if_PDF_is_displayed() {
	    Elements.isDisplayed(pageObjects.PDF);
	}

	@Then("click on Inbox")
	public void click_on_Inbox() throws InterruptedException {
		Thread.sleep(5000);
		Elements.click(pageObjects.Inbox);
	}

	@Then("select an Email and select option send to from Actions dropdown")
	public void select_an_Email_and_select_option_send_to_from_Actions_dropdown() throws InterruptedException {
		Elements.click(pageObjects.Mail_Selection);
		Waits.waitUntilElementToClick(5, pageObjects.Action_drpdwn);
		Elements.click(pageObjects.Action_drpdwn);
		Waits.waitUntilElementToClick(5, pageObjects.Action_Selection);
		Elements.click(pageObjects.Action_Selection);
		Thread.sleep(7000);
	}

	@Then("search recipient {string} and select")
	public void search_recipient_and_select(String recipient) throws InterruptedException {
		Elements.TypeText(pageObjects.Recipent_Search, recipient);
		Thread.sleep(7000);
		Elements.click(pageObjects.Recipent_Selection(recipient));
	}

	@Then("click on send button")
	public void click_on_send_button() {
		Elements.click(pageObjects.Send_btn);
	}

	@Then("click on send email option")
	public void click_on_send_email_option() {
		Elements.click(pageObjects.SendMail);
	}

	@Then("click on user dashboard")
	public void click_on_user_dashboard() throws InterruptedException {
		//Waits.waitUntilElementToClick(5, pageObjects.User_Dashboard);
		Thread.sleep(5000);
		pageObjects.User_Dashboard();
	}

	@Then("verify values are displayed for Total Mail, Opened Mail and Un Opened Mail")
	public void verify_values_are_displayed_for_Total_Mail_Opened_Mail_and_Un_Opened_Mail() {
	    String TotalMailValue = Elements.getText(pageObjects.TotalMailValue);
	    String OpenedMailValue = Elements.getText(pageObjects.OpenedMailValue);
	    String UnOpenedMailValue = Elements.getText(pageObjects.UnOpenedMailValue);
	    
	    Assert.assertNotNull(TotalMailValue);  
	    Assert.assertNotNull(OpenedMailValue);
	    Assert.assertNotNull(UnOpenedMailValue);
	}

	
	@Then("click on Switch Role")
	public void click_on_Switche_Home() {
		Elements.click(pageObjects.SwitchRole);
	}

	@Then("Select {string}") 
	public void select_client_admin	(String string) throws InterruptedException  {
		Elements.click(pageObjects.clientAdmin(string));
		Thread.sleep(2000);
		Elements.click(pageObjects.ClientAdmin_OkC);
	}

	@Then("click on Reports")
	public void click_on_Reports() {
		Elements.jclick(pageObjects.Reports);
	}

	@Then("select Volume Report from dropdown")
	public void select_Volume_Report_from_dropdown() throws InterruptedException {
		
		//Elements.jclick(pageObjects.Menuexpand);
		Thread.sleep(1000);
		Elements.Jclick(pageObjects.Reports_Selection);
	}

	@Then("check value is displayed for total volume")
	public void check_value_is_displayed_for_total_volume() throws InterruptedException {
		Thread.sleep(10000);
		String TotalVolume = Elements.getText(pageObjects.TotalVolume);
		Assert.assertNotNull(TotalVolume);
	}
	
}