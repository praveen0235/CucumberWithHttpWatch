package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import baseinit.Base;

public class pageObjects {
	
	public pageObjects(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//input[@aria-label='User Name']")
	public static WebElement username;
	
	@FindBy(xpath="//app-toast[@class='ng-star-inserted']//span")
	public static WebElement AlertMsg;
	
	@FindBy(xpath="//input[@name='loginPassword']")
	public static WebElement password;
	
	@FindBy(xpath="//button[@aria-label='Switch Role']")
	public static WebElement SwitchToRole;
	
	@FindBy(xpath="//mat-icon[text()='menu']")
	public static WebElement Menu;
	
	@FindBy(xpath="//div[contains(text(),'Corporation. LLC')]")
	public static WebElement Dashboard;
	
	public static WebElement SwitchToRole_Radiobtn(String data)
	{
		String Xpath = "//div[contains(text(),'$')]";
		WebElement element = Base.driver.findElement(By.xpath(Xpath.replace("$", data)));
		return element;
	}
	
	@FindBy(xpath="//span[text()='OK']")
	public static WebElement OK_btn;
	
	@FindBy(xpath="//*[text()='Next']")
	public static WebElement Next_btn;
	
	@FindBy(xpath="//*[text()='LOGIN']")
	public static WebElement SignInButton;
	
	@FindBy(xpath="//span[@title='DMR_CORE']/parent::td//following-sibling::td[3]/span")
	public static WebElement DMR_CORE_Status;
	
	@FindBy(xpath="//span[@title='DMR_CORE']/parent::td//following-sibling::td[2]/span")
	public static WebElement DMR_CORE_DBStatus;
	
	@FindBy(xpath="//span[@title='Ingester']/parent::td//following-sibling::td[3]/span")
	public static WebElement Ingester_Status;
	
	@FindBy(xpath="//span[contains(@title,'eFirst-Archive')]/parent::td//following-sibling::td[3]/span")
	public static WebElement eFirst_Archive_DEMO_Status;
	
	@FindBy(xpath="//span[@title='EXELA_AUTH']/parent::td//following-sibling::td[3]/span")
	public static WebElement Exela_Auth_Status;
	
	@FindBy(xpath="//span[@title='EXELA_AUTH']/parent::td//following-sibling::td[2]/span")
	public static WebElement Exela_Auth_DBStatus;
	
	@FindBy(xpath="//md-select[@name='Select Project']/div")
	public static WebElement Select_Prjct_drpdwn;
	
	@FindBy(xpath="//md-option[contains(text(),'$')]")
	public static WebElement Project_Selection;
	
	@FindBy(xpath="(//td//input[@type='checkbox']/parent::div)[1]")
	public static WebElement Mail_Selection;
	
	@FindBy(xpath="//tr[1]//td[1]//i[@class='drag-handle fa fa-arrows-alt ']")
	public static WebElement DoubleClick_OpenMail;
	
	@FindBy(xpath="//div[@class='pdfViewer removePageBorders']//canvas")
	public static WebElement PDF;
	
	@FindBy(xpath="//a[@title='Inbox' and @role='link']")
	public static WebElement Inbox;
	
	@FindBy(xpath="(//span[text()='Select Action' and @class = 'mat-select-value-text'])[1]")
	public static WebElement Action_drpdwn;
	
	@FindBy(xpath="//md-option[contains(text(),'Send To')]")
	public static WebElement Action_Selection;
	
	@FindBy(xpath="//span[text()='Ok']")
	public static WebElement ClientAdmin_Ok;
	
	@FindBy(xpath="//span[text()='OK']")
	public static WebElement ClientAdmin_OkC;
	
	public static WebElement Recipent_Selection(String data)
	{
		String otp = "//div[@class='ui-helper-clearfix']/div[@title='$']";
		WebElement Recipent_Selection = Base.driver.findElement(By.xpath(otp.replace("$", data)));
		return Recipent_Selection;
	}
	
	public static WebElement clientAdmin(String data)
	{
		String clientAdmin = "//div[contains(text(),'$')]";
		WebElement WebclientAdmin = Base.driver.findElement(By.xpath(clientAdmin.replace("$", data)));
		return WebclientAdmin;
	}
	
	@FindBy(xpath="//button//span[contains(text(),'Send')]")
	public static WebElement Send_btn;
	
	@FindBy(xpath="//a[text()='Send Mail']")
	public static WebElement SendMail;
	
	@FindBy(xpath="//span[text()='user-dashboard']")
	public static WebElement User_Dashboard;
	
	public static void User_Dashboard()
	{
		 Base.driver.navigate().to("https://dmr-demo.exela.global/#/payroll/user-dashboard");;	
	}
	
	@FindBy(xpath="//md-icon[text()='menu']")
	public static WebElement ToggleMenu;
	
	@FindBy(xpath="//span[text()='TOTAL MAIL']//parent::div/h3")
	public static WebElement TotalMailValue;
	
	@FindBy(xpath="//span[text()='OPENED MAIL']//parent::div/h3")
	public static WebElement OpenedMailValue;
	
	@FindBy(xpath="//span[text()='UNOPENED MAIL']//parent::div/h3")
	public static WebElement UnOpenedMailValue;
	
	@FindBy(xpath="//a[@aria-label='Reports']/span[@class='mat-list-item-content']")
	public static WebElement Reports;
	
	@FindBy(xpath="//md-select[@aria-label='Reports']/div")
	public static WebElement Reports_drpdwn;
	
	@FindBy(xpath="//span[text()='Volume Report']")
	public static WebElement Reports_Selection;
	
	@FindBy(xpath="//md-option[contains(text(),'Inventory Report')]")
	public static WebElement InventoryReport;
	
	@FindBy(xpath="(//td[1])[1]/span/span")
	public static WebElement DCNNumber;
	
	@FindBy(xpath="//li[@class='ui-autocomplete-input-token']/input")
	public static WebElement Recipent_Search;
	
	@FindBy(xpath="//h2/a")
	public static WebElement TotalVolume;
	
	@FindBy(xpath="//i[@title='Profile Photo']")
	public static WebElement Profile_Pic;
	
	@FindBy(xpath="//button[text()='Logout']")
	public static WebElement Logout;
	
	@FindBy(xpath="//a[text()='Switch Role']")
	public static WebElement SwitchRole;
	
	@FindBy(xpath="//mat-icon[contains(text(),'menu')]")
	public static WebElement Menuexpand;
	
}
