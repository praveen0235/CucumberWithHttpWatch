package com.httpwatch  ;

import com4j.*;

/**
 */
public enum OLECMDEXECOPT {
  /**
   * <p>
   * The value of this constant is 0
   * </p>
   */
  OLECMDEXECOPT_DODEFAULT, // 0
  /**
   * <p>
   * The value of this constant is 1
   * </p>
   */
  OLECMDEXECOPT_PROMPTUSER, // 1
  /**
   * <p>
   * The value of this constant is 2
   * </p>
   */
  OLECMDEXECOPT_DONTPROMPTUSER, // 2
  /**
   * <p>
   * The value of this constant is 3
   * </p>
   */
  OLECMDEXECOPT_SHOWHELP, // 3
}
