package com.httpwatch  ;

import com4j.*;

/**
 */
public enum tagREADYSTATE {
  /**
   * <p>
   * The value of this constant is 0
   * </p>
   */
  READYSTATE_UNINITIALIZED, // 0
  /**
   * <p>
   * The value of this constant is 1
   * </p>
   */
  READYSTATE_LOADING, // 1
  /**
   * <p>
   * The value of this constant is 2
   * </p>
   */
  READYSTATE_LOADED, // 2
  /**
   * <p>
   * The value of this constant is 3
   * </p>
   */
  READYSTATE_INTERACTIVE, // 3
  /**
   * <p>
   * The value of this constant is 4
   * </p>
   */
  READYSTATE_COMPLETE, // 4
}
