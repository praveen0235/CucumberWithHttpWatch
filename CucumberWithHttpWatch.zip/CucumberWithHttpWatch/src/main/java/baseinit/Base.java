package baseinit;

import java.io.File;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.SystemUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.httpwatch.ClassFactory;
import com.httpwatch.IController;
import com.httpwatch.Plugin;
import com.httpwatch.Summary;

import config.ConfigurationReader;
import config.PropertyFileReader;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.AfterStep;
import cucumber.api.java.Before;
import cucumber.api.java.BeforeStep;
import framework.Browser;
import framework.GenericActions;
import framework.Waits;
import reporter.ExtentCucumberAdapter;
import util.PathHelper;
import util.Xls_Reader;


public class Base {
	
	public static Logger log=Logger.getLogger(Base.class);
	public static String mainWindowHandle;
	public static WebDriver driver;
	public static ConfigurationReader reader;

	public static Xls_Reader suiteXLS = new Xls_Reader(PathHelper.getBasePath()+"/test-output/ExcelReport/ExcelReport.xlsx");
	//public static int rowcount = suiteXLS.getRowCount("TestSuite");
	public static Xls_Reader suiteXLS1 = new Xls_Reader(PathHelper.getBasePath()+"/test-output/ExcelReport/ExcelReportPref.xlsx");
	public static int currentRowCount = 2;
	public static int currentRowCountPrefFile = 2;
	public static int currentHttpWatchRow = 0;
	static Map<String,Float> stepNameAndTiming;
	String URL;
	IController	controller;
	Plugin	plugin;
	
	public static void expectedTimingSetup()
	{
		stepNameAndTiming = new HashMap<String,Float>();
		
		for(int i=2;i<=suiteXLS1.getRowCount("ExpectedTime");i++)
		{
			stepNameAndTiming.put(suiteXLS1.getCellData("ExpectedTime", "TestStepDescription", i), Float.parseFloat(suiteXLS1.getCellData("ExpectedTime", "ExpectedTiming", i)));
		}
		int i=1;
	}
	
	@Before
	public void BrowsersetUp(Scenario browser){
		final File theDir = new File(String.valueOf(System.getProperty("user.dir")) + "/test-output/HttpWatch/"+ExtentCucumberAdapter.scenarioName.replaceAll("[^a-zA-Z0-9]", ""));
        if (!theDir.exists()) {
            theDir.mkdir();
        }
		log.info("Scenario Started: "+browser.getName());
		Base.reader=new PropertyFileReader();
		Browser.startBrowser();
		Browser.maximize();
		mainWindowHandle=driver.getWindowHandle();
		
				GenericActions.date(suiteXLS, "TestStartedTime", currentRowCount);
				suiteXLS.setCellData("TestSuite", "Investigations", currentRowCount, "");
				suiteXLS.setCellData("TestSuite", "SlNo", currentRowCount, String.valueOf(currentRowCount-1));
				suiteXLS.setCellData("TestSuite", "TCID", currentRowCount, "TC00"+String.valueOf(currentRowCount-1));
				suiteXLS.setCellData("TestSuite", "Product", currentRowCount, PropertyFileReader.properties.getProperty("Product"));
				suiteXLS.setCellData("TestSuite", "Browser", currentRowCount, PropertyFileReader.properties.getProperty("browser"));
				suiteXLS.setCellData("TestSuite", "URL", currentRowCount, PropertyFileReader.properties.getProperty("url").replace("https://", "").replace("http://", ""));
				suiteXLS.setCellData("TestSuite", "Environment", currentRowCount, PropertyFileReader.properties.getProperty("Environment"));
				GenericActions.date(suiteXLS, "TestStartedTime", currentRowCount);
				
			
		
	}
	
	@BeforeStep
	public void beforeStep()
	{
		if(currentHttpWatchRow>1)
    	{
		controller = ClassFactory.createController();
		String title =driver.getTitle();	
		plugin = controller.attachByTitle(title);
		plugin.clear();
		plugin.clearAllCookies();
		plugin.clearCache();
		//plugin.ClearAllCookiesMethod();
		plugin.record();
    	}
	}
	@AfterStep
	public void waitToPageRender(Scenario scenario) throws InterruptedException
	{
		//((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete|loaded|interactive");
		
		for(int i=1;i<=60;i++)
		{
			if(Waits.isPageLoaded())
			{
				break;
			}
			
			Thread.sleep(1000);
		}
		
		
		/*
		 * suiteXLS1.setCellData("TestSuite", "Investigations", currentRowCount, "");
		 * suiteXLS1.setCellData("TestSuite", "SlNo", currentRowCountPrefFile,
		 * String.valueOf(currentRowCountPrefFile-1));
		 * suiteXLS1.setCellData("TestSuite", "TCID", currentRowCountPrefFile,
		 * "TC00"+String.valueOf(currentRowCount-1)); suiteXLS1.setCellData("TestSuite",
		 * "Product", currentRowCountPrefFile,
		 * PropertyFileReader.properties.getProperty("Product"));
		 * suiteXLS1.setCellData("TestSuite", "Browser", currentRowCountPrefFile,
		 * PropertyFileReader.properties.getProperty("browser"));
		 * suiteXLS1.setCellData("TestSuite", "URL", currentRowCountPrefFile,
		 * PropertyFileReader.properties.getProperty("url").replace("https://",
		 * "").replace("http://", "")); suiteXLS1.setCellData("TestSuite",
		 * "Environment", currentRowCountPrefFile,
		 * PropertyFileReader.properties.getProperty("Environment"));
		 */
		
		 Base.suiteXLS1.setCellData("TestSuite", "TestStepDescription", Base.currentRowCountPrefFile, ExtentCucumberAdapter.stepname );//praveen
	        Base.suiteXLS1.setCellData("TestSuite", "TestCaseDescription", Base.currentRowCountPrefFile, ExtentCucumberAdapter.scenarioName );//praveen
	       // Base.suiteXLS1.setCellData("TestSuite", "Investigations", Base.currentRowCountPrefFile, "");
	        Base.suiteXLS1.setCellData("TestSuite", "SlNo", Base.currentRowCountPrefFile, String.valueOf(Base.currentRowCountPrefFile-1));
	        Base.suiteXLS1.setCellData("TestSuite", "TCID", Base.currentRowCountPrefFile, "TC00"+String.valueOf(Base.currentRowCount-1));
	        Base.suiteXLS1.setCellData("TestSuite", "Product", Base.currentRowCountPrefFile, PropertyFileReader.properties.getProperty("Product"));
	        Base.suiteXLS1.setCellData("TestSuite", "Browser", Base.currentRowCountPrefFile, PropertyFileReader.properties.getProperty("browser"));
	        Base.suiteXLS1.setCellData("TestSuite", "URL", Base.currentRowCountPrefFile, PropertyFileReader.properties.getProperty("url").replace("https://", "").replace("http://", ""));
	        Base.suiteXLS1.setCellData("TestSuite", "Environment", Base.currentRowCountPrefFile, PropertyFileReader.properties.getProperty("Environment"));
	        
			/*
			 * long navigationStart = (long)((JavascriptExecutor)Base.driver).
			 * executeScript("return window.performance.timing.navigationStart"); long
			 * responseStart = (long)((JavascriptExecutor)Base.driver).
			 * executeScript("return window.performance.timing.responseStart"); long
			 * domComplete = (long)((JavascriptExecutor)Base.driver).
			 * executeScript("return window.performance.timing.domComplete");
			 * 
			 * long backendPerformance_calc = responseStart - navigationStart; long
			 * frontendPerformance_calc = domComplete - responseStart;
			 * 
			 * long totalTime = backendPerformance_calc+frontendPerformance_calc;
			 * 
			 * long timeInSec = TimeUnit.MILLISECONDS.toSeconds(totalTime);
			 */
	        
	        if(currentHttpWatchRow==0)
	    	{
	    	
	        	double loadTime = (double) ((JavascriptExecutor)Base.driver).executeScript(
			  "return (window.performance.timing.loadEventEnd - window.performance.timing.navigationStart) / 1000"
			  );
			  
			  Base.suiteXLS1.setCellData("TestSuite", "PerfTiming", Base.currentRowCountPrefFile, String.valueOf(loadTime));
		        
				/*
				 * if(Double.parseDouble(PropertyFileReader.properties.getProperty(
				 * "PerformanceTiming"))<(loadTime)) { Base.suiteXLS1.setCellData("TestSuite",
				 * "perfStatus", Base.currentRowCountPrefFile, "PerformanceIssue" ); }
				 */
		        
		        //float diffValue = stepNameAndTiming.get(ExtentCucumberAdapter.stepname)-(float)loadTime;
		        
		        float diffValue = (float) (loadTime-stepNameAndTiming.get(ExtentCucumberAdapter.stepname));
		        
		        if((loadTime>stepNameAndTiming.get(ExtentCucumberAdapter.stepname)&&diffValue>5))
		        {
		        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "Worst" );
		        }else if(loadTime>stepNameAndTiming.get(ExtentCucumberAdapter.stepname)&&(diffValue>3&&diffValue<5))
		        {
		        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "poor" );
		        }else if(loadTime>stepNameAndTiming.get(ExtentCucumberAdapter.stepname)&&diffValue<3)
		        {
		        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "Good" );
		        }else
		        {
		        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "Good" );
		        }
	    	}
	        
	    	 
	        	
	    	
	    	if(currentHttpWatchRow>1)
	    	{
	        controller.wait_(plugin, 10);
	    		
	      //stop recording for transaction
	      plugin.stop();

	      /*Get the Summary of Performance KPI*/
	      if(plugin.log().pages().count()!=0)
	      {
	      Summary  summary = plugin.log().pages(plugin.log().pages().count()-1).entries().summary();
	      
	      //Summary  summary =  plugin.log().pages().item(plugin.log().pages().count()).entries().summary();

	      System.out.println(" Summary Time" + summary.time());
	      System.out.println( "Total time to load page (secs): " +
	      summary.time());
	      System.out.println( "Number of bytes received on network: " +
	      summary.bytesReceived());
	      System.out.println( "HTTP compression saving (bytes): " +
	      summary.compressionSavedBytes());
	      System.out.println( "Number of round trips: " +
	      summary.roundTrips());
	      System.out.println( "Number of errors: " +
	      summary.errors().count());
	      plugin.log().save(System.getProperty("user.dir")+"/test-output/HttpWatch/"+ExtentCucumberAdapter.scenarioName.replaceAll("[^a-zA-Z0-9]", "")+"/"+ExtentCucumberAdapter.stepname.replaceAll("[^a-zA-Z0-9]", "")+".hwl");
	        System.out.println(summary.time());
	       
	        
	        Base.suiteXLS1.setCellData("TestSuite", "PerfTiming", Base.currentRowCountPrefFile, String.valueOf(summary.time()));
	        
	        float diffValue = (float)summary.time()-stepNameAndTiming.get(ExtentCucumberAdapter.stepname);
	        
	        if((float)summary.time()>stepNameAndTiming.get(ExtentCucumberAdapter.stepname)&&diffValue>5)
	        {
	        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "Worst" );
	        }else if((float)summary.time()>stepNameAndTiming.get(ExtentCucumberAdapter.stepname)&&(diffValue>3&&diffValue<5))
	        {
	        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "poor" );
	        }else if((float)summary.time()>stepNameAndTiming.get(ExtentCucumberAdapter.stepname)&&diffValue<3)
	        {
	        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "Good" );
	        }else
	        {
	        	Base.suiteXLS1.setCellData("TestSuite", "perfStatus", Base.currentRowCountPrefFile, "Good" );
	        }
	        summary.dispose();
	      }
	        
	            
	        
			/*
			 * if(backendPerformance_calc>frontendPerformance_calc) {
			 * Base.suiteXLS1.setCellData("TestSuite", "PerfTiming",
			 * Base.currentRowCountPrefFile,
			 * String.valueOf(((int)backendPerformance_calc)/1000%60) );
			 * 
			 * if(Integer.parseInt(PropertyFileReader.properties.getProperty(
			 * "PerformanceTiming"))<((int)backendPerformance_calc)/1000%60) {
			 * Base.suiteXLS1.setCellData("TestSuite", "perfStatus",
			 * Base.currentRowCountPrefFile, "PerformanceIssue" ); }
			 * 
			 * }else { Base.suiteXLS1.setCellData("TestSuite", "PerfTiming",
			 * Base.currentRowCountPrefFile,
			 * String.valueOf(((int)frontendPerformance_calc)/1000%60) );
			 * 
			 * if(Integer.parseInt(PropertyFileReader.properties.getProperty(
			 * "PerformanceTiming"))<((int)frontendPerformance_calc)/1000%60) {
			 * Base.suiteXLS1.setCellData("TestSuite", "perfStatus",
			 * Base.currentRowCountPrefFile, "PerformanceIssue" ); } }
			 */
	        

	       
	        
	       System.out.println( "____________"+plugin.log().pages().count());
	       plugin.dispose();
	       
	        controller.dispose();  
	        
	}
	      //  System.out.println( "____________"+plugin.log().pages().count());
	        Base.suiteXLS1.setCellData("TestSuite", "Result", Base.currentRowCountPrefFile, ExtentCucumberAdapter.stepResult);
	        
	       
	        currentHttpWatchRow++;  
		currentRowCountPrefFile++;
		
		if(PropertyFileReader.properties.getProperty("ScreenShotforEachSteps").toLowerCase().equalsIgnoreCase("yes"))
		{
			scenario.embed(Browser.takeScreenshot(scenario), "image/png");
		}
	}
	
	@After
	
	public void closeBrowser(Scenario scenario) throws ParseException{
		currentHttpWatchRow = 0;
		if(scenario.isFailed()){
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmSSSss");
			LocalDateTime now = LocalDateTime.now();
			String dummyy = dtf.format(now).toString();
			String dummy = dummyy.substring(0, 15);
			scenario.embed(Browser.takeScreenshot(scenario), "image/png");
			/*for(int i=1;i<=rowcount;i++)
			{
				if(suiteXLS.getCellData("TestSuite", "TestCaseDescription", i).equalsIgnoreCase(scenario.getName()))
				{
					suiteXLS.setCellData("TestSuite", "Investigations", i, "Unable to locate the element");
					break;
				}
			}*/
			//Browser.takeScreenshot(scenario);
		}
		
		
				suiteXLS.setCellData("TestSuite", "Result", currentRowCount, String.valueOf(scenario.getStatus()));
				GenericActions.date(suiteXLS, "TestEndedTime", currentRowCount);
				String startdate= suiteXLS.getCellData("TestSuite", "TestStartedTime", currentRowCount);
				String Enddate= suiteXLS.getCellData("TestSuite", "TestEndedTime", currentRowCount);
				GenericActions.datediff(startdate, Enddate, suiteXLS, currentRowCount);
				
		
		log.info("Scenario Completed: "+scenario.getName());
		log.info("Scenario Status is: "+scenario.getStatus());
		Base.driver.quit();
		currentRowCount++;
		//scenario.write("Lanched URL");
		try
		 {
			 if (SystemUtils.IS_OS_WINDOWS)
			    { 
				 	Runtime.getRuntime().exec("taskkill /F /PID "+Browser.chromeDriverProcessID);
				 	Runtime.getRuntime().exec("taskkill /F /PID "+Browser.chromeProcessID);
				 	
			    }else if(SystemUtils.IS_OS_LINUX)
			    {
			    	Runtime.getRuntime().exec("sudo kill "+Browser.chromeDriverProcessID);
			    	Runtime.getRuntime().exec("sudo kill "+Browser.chromeProcessID);
			    }
		 }catch(Exception e)
		 {
			 
		 }
		}
	 
	}


